using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ServiceModule.Pages
{
    public class registerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
