using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ServiceModule.Pages
{
    public class dashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
